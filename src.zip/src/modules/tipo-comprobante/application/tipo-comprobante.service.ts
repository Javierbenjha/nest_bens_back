import { Inject, Injectable } from '@nestjs/common';
import type { TipoComprobanteRepository } from '../domain/tipo-comprobante.repository';

@Injectable()
export class TipoComprobanteService {
  constructor(
    @Inject('TipoComprobanteRepository')
    private readonly repo: TipoComprobanteRepository,
  ) {}

  findAll() {
    return this.repo.findAll();
  }
}
