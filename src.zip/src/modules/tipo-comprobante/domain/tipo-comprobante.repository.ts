import { TipoComprobante } from './tipo-comprobante.entity';

export interface TipoComprobanteRepository {
    findAll(): Promise<TipoComprobante[]>;
    findById(id: number): Promise<TipoComprobante | null>;
}
