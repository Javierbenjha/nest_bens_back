import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { Controller, Get } from '@nestjs/common';
import { TipoComprobanteService } from '../../application/tipo-comprobante.service';
import { Public } from '../../../../common/decorators/public.decorator';

@ApiTags('Tipo-comprobante')
@ApiBearerAuth()
@Controller('tipo-comprobante')
export class TipoComprobanteController {
  constructor(private readonly service: TipoComprobanteService) {}

  @Public()
  @Get()
  findAll() {
    return this.service.findAll();
  }
}
